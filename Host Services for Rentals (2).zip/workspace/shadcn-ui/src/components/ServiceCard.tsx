import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { LucideIcon } from 'lucide-react';

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  features: string[];
}

export default function ServiceCard({ icon: Icon, title, description, features }: ServiceCardProps) {
  return (
    <Card className="h-full border-0 shadow-lg hover:shadow-xl transition-all duration-300 hover:-translate-y-1">
      <CardHeader>
        <div className="w-12 h-12 bg-navy-100 rounded-lg flex items-center justify-center mb-4">
          <Icon className="w-6 h-6 text-navy-600" />
        </div>
        <CardTitle className="text-xl text-navy-900">{title}</CardTitle>
        <CardDescription className="text-gray-600">
          {description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          {features.map((feature, index) => (
            <Badge key={index} variant="secondary" className="mr-2 mb-2">
              {feature}
            </Badge>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}