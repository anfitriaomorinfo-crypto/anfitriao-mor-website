import { Card, CardContent } from '@/components/ui/card';

export default function StatsSection() {
  const stats = [
    { number: '300%', label: 'Aumento médio de renda', description: 'vs aluguel tradicional' },
    { number: '95%', label: 'Taxa de ocupação', description: 'média anual' },
    { number: '4.9/5', label: 'Avaliação média', description: 'dos hóspedes' },
    { number: '24/7', label: 'Suporte disponível', description: 'todos os dias' }
  ];

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-4xl mx-auto">
      {stats.map((stat, index) => (
        <Card key={index} className="border-0 bg-white/50 backdrop-blur-sm">
          <CardContent className="p-4 text-center">
            <div className="text-2xl md:text-3xl font-bold text-navy-700 mb-1">
              {stat.number}
            </div>
            <div className="text-sm font-semibold text-navy-900 mb-1">
              {stat.label}
            </div>
            <div className="text-xs text-gray-600">
              {stat.description}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}