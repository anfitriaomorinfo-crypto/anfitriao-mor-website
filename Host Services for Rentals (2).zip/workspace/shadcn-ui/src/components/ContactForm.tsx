import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { toast } from 'sonner';
import { Send } from 'lucide-react';

export default function ContactForm() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    propertyType: '',
    location: '',
    message: '',
    hasProperty: false,
    interestedServices: []
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Basic validation
    if (!formData.name || !formData.email || !formData.phone) {
      toast.error('Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    // Simulate form submission
    toast.success('Mensagem enviada com sucesso! Entraremos em contato em breve.');
    
    // Reset form
    setFormData({
      name: '',
      email: '',
      phone: '',
      propertyType: '',
      location: '',
      message: '',
      hasProperty: false,
      interestedServices: []
    });
  };

  const handleInputChange = (field: string, value: string | boolean) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  return (
    <Card className="shadow-lg">
      <CardHeader>
        <CardTitle className="text-2xl">Solicite sua Consultoria Gratuita</CardTitle>
        <CardDescription>
          Preencha o formulário e descubra como podemos ajudar você a maximizar a renda do seu imóvel
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name">Nome *</Label>
              <Input
                id="name"
                value={formData.name}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Seu nome completo"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => handleInputChange('email', e.target.value)}
                placeholder="seu@email.com"
                required
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="phone">Telefone *</Label>
              <Input
                id="phone"
                value={formData.phone}
                onChange={(e) => handleInputChange('phone', e.target.value)}
                placeholder="(41) 99999-9999"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="location">Localização do Imóvel</Label>
              <Input
                id="location"
                value={formData.location}
                onChange={(e) => handleInputChange('location', e.target.value)}
                placeholder="Cidade/Bairro"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="propertyType">Tipo de Propriedade</Label>
            <Select onValueChange={(value) => handleInputChange('propertyType', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Selecione o tipo de propriedade" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="apartamento">Apartamento</SelectItem>
                <SelectItem value="casa">Casa</SelectItem>
                <SelectItem value="kitnet">Kitnet/Studio</SelectItem>
                <SelectItem value="loft">Loft</SelectItem>
                <SelectItem value="cobertura">Cobertura</SelectItem>
                <SelectItem value="outros">Outros</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center space-x-2">
            <Checkbox
              id="hasProperty"
              checked={formData.hasProperty}
              onCheckedChange={(checked) => handleInputChange('hasProperty', checked as boolean)}
            />
            <Label htmlFor="hasProperty" className="text-sm">
              Já possuo uma propriedade para aluguel por temporada
            </Label>
          </div>

          <div className="space-y-2">
            <Label htmlFor="message">Mensagem</Label>
            <Textarea
              id="message"
              value={formData.message}
              onChange={(e) => handleInputChange('message', e.target.value)}
              placeholder="Conte-nos mais sobre seu imóvel e seus objetivos..."
              rows={4}
            />
          </div>

          <div className="bg-gradient-to-br from-navy-50 to-gold-50 p-4 rounded-lg border border-navy-100">
            <h4 className="font-semibold text-navy-900 mb-2">O que você receberá:</h4>
            <ul className="text-sm text-gray-600 space-y-1">
              <li>✓ Análise gratuita do potencial de renda do seu imóvel</li>
              <li>✓ Estratégias personalizadas de precificação</li>
              <li>✓ Plano de ação para maximizar seus lucros</li>
              <li>✓ Consultoria sem compromisso</li>
            </ul>
          </div>

          <Button type="submit" className="w-full bg-navy-800 hover:bg-navy-900 text-white" size="lg">
            <Send className="w-5 h-5 mr-2" />
            Solicitar Consultoria Gratuita
          </Button>

          <p className="text-xs text-gray-500 text-center">
            Ao enviar este formulário, você concorda em receber comunicações da Anfitrião-mor. 
            Seus dados estão seguros conosco.
          </p>
        </form>
      </CardContent>
    </Card>
  );
}