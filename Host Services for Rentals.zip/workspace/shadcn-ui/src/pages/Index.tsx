import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Star, Shield, Clock, TrendingUp, Users, CheckCircle, Phone, Mail, MessageCircle } from 'lucide-react';
import ContactForm from '@/components/ContactForm';
import ServiceCard from '@/components/ServiceCard';
import TestimonialCard from '@/components/TestimonialCard';
import StatsSection from '@/components/StatsSection';
import HollandCarousel from '@/components/HollandCarousel';

export default function Index() {
  const scrollToContact = () => {
    document.getElementById('contact')?.scrollIntoView({ behavior: 'smooth' });
  };

  const services = [
    {
      icon: TrendingUp,
      title: "Maximização de Lucros",
      description: "Utilizamos tecnologias de precificação dinâmica para ajustar valores em tempo real, considerando demanda, eventos locais e concorrência.",
      features: ["Dynamic Pricing", "Análise de Mercado", "Otimização de Receita"]
    },
    {
      icon: Shield,
      title: "Gestão Completa e Automatizada",
      description: "Processos otimizados com automação em cada etapa, da comunicação com hóspedes à gestão de reservas.",
      features: ["Suporte 24/7", "Administração Completa", "Manutenção Preventiva"]
    },
    {
      icon: Star,
      title: "Foco na Qualidade e Detalhe",
      description: "Equipe treinada para a perfeição, buscando superar expectativas e alcançar o selo de Superhost.",
      features: ["Avaliações 5 Estrelas", "Certificação Superhost", "Atenção aos Detalhes"]
    }
  ];

  const testimonials = [
    {
      name: "Maria Silva",
      location: "Curitiba, PR",
      rating: 5,
      text: "Desde que confiei meu apartamento à Anfitrião-mor, minha renda mensal triplicou. O suporte é excepcional!"
    },
    {
      name: "João Santos",
      location: "Amsterdam, NL",
      rating: 5,
      text: "Profissionalismo europeu com o carinho brasileiro. Minha propriedade sempre impecável e bem avaliada."
    },
    {
      name: "Ana Costa",
      location: "Curitiba, PR",
      rating: 5,
      text: "Consegui o selo Superhost em apenas 3 meses. A diferença na qualidade do serviço é notável."
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="fixed top-0 w-full bg-white/95 backdrop-blur-sm border-b z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center space-x-3">
            <img 
              src="/assets/logo.png" 
              alt="Anfitrião-mor Logo" 
              className="w-10 h-10 object-contain"
            />
            <span className="text-xl font-bold text-navy-900">Anfitrião-mor</span>
          </div>
          <nav className="hidden md:flex space-x-8">
            <a href="#about" className="text-gray-600 hover:text-navy-600 transition-colors">Sobre</a>
            <a href="#services" className="text-gray-600 hover:text-navy-600 transition-colors">Serviços</a>
            <a href="#holland" className="text-gray-600 hover:text-navy-600 transition-colors">Holanda</a>
            <a href="#testimonials" className="text-gray-600 hover:text-navy-600 transition-colors">Depoimentos</a>
            <a href="#contact" className="text-gray-600 hover:text-navy-600 transition-colors">Contato</a>
          </nav>
          <Button onClick={scrollToContact} className="bg-navy-800 hover:bg-navy-900 text-white">
            Comece Agora
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="pt-24 pb-16 bg-gradient-to-br from-gray-50 to-gold-50">
        <div className="container mx-auto px-4 text-center">
          <Badge className="mb-6 bg-navy-100 text-navy-800 hover:bg-navy-100">
            <MapPin className="w-4 h-4 mr-1" />
            Expertise Internacional • Amsterdam → Curitiba
          </Badge>
          
          <h1 className="text-4xl md:text-6xl font-bold text-navy-900 mb-6 leading-tight">
            Transforme sua propriedade em uma
            <span className="bg-gradient-to-r from-navy-600 to-navy-800 bg-clip-text text-transparent"> fonte de renda</span>
          </h1>
          
          <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
            Gestão completa e automatizada para Airbnb, Booking e Vrbo. 
            Maximize seus lucros com nossa expertise internacional e conhecimento local.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button onClick={scrollToContact} size="lg" className="bg-navy-800 hover:bg-navy-900 text-white text-lg px-8">
              <MessageCircle className="w-5 h-5 mr-2" />
              Solicitar Consultoria Gratuita
            </Button>
            <Button variant="outline" size="lg" className="text-lg px-8 border-navy-600 text-navy-700 hover:bg-navy-50">
              <Phone className="w-5 h-5 mr-2" />
              (41) 98747-6580
            </Button>
          </div>

          <StatsSection />
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-center text-navy-900 mb-12">
              Nossa História
            </h2>
            
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-semibold text-navy-900 mb-4">
                  De Amsterdam para Curitiba
                </h3>
                <p className="text-gray-600 mb-6">
                  A "Anfitrião Mor" nasceu da experiência prática e da paixão pela hospitalidade, 
                  com nossas primeiras operações estabelecidas em Amsterdam, um dos mercados de 
                  aluguel de curta temporada mais dinâmicos e exigentes do mundo.
                </p>
                <p className="text-gray-600 mb-6">
                  Estudamos a fundo os conceitos de gestão de hotelaria e a importância da automação 
                  de processos. Aplicamos essas lições para criar um modelo de negócio eficiente, 
                  que garante a máxima rentabilidade e um serviço de 5 estrelas.
                </p>
                
                <div className="space-y-3">
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-gray-700">Expertise internacional</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-gray-700">Conhecimento do mercado local</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-500 mr-3" />
                    <span className="text-gray-700">Processos automatizados</span>
                  </div>
                </div>
              </div>
              
              <div className="bg-gradient-to-br from-navy-50 to-gold-50 p-8 rounded-2xl border border-navy-100">
                <h4 className="text-xl font-semibold text-navy-900 mb-4">
                  Por que Curitiba?
                </h4>
                <p className="text-gray-600 mb-4">
                  Após o sucesso em Amsterdam, trouxemos nossa expertise para o Brasil, 
                  escolhendo Curitiba como nosso ponto de partida.
                </p>
                <p className="text-gray-600">
                  A cidade se destaca por sua combinação estratégica de um forte polo econômico, 
                  atraindo viajantes a negócios, e uma crescente demanda por lazer e cultura.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Holland Carousel Section */}
      <section id="holland">
        <HollandCarousel />
      </section>

      {/* Services Section */}
      <section id="services" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
              Nossos Serviços
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Cuidamos de cada detalhe, garantindo que seu imóvel seja uma fonte de renda 
              e uma experiência de alto padrão para cada hóspede.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 mb-16">
            {services.map((service, index) => (
              <ServiceCard key={index} {...service} />
            ))}
          </div>

          <div className="text-center">
            <Button onClick={scrollToContact} size="lg" className="bg-navy-800 hover:bg-navy-900 text-white">
              Quero Saber Mais Sobre os Serviços
            </Button>
          </div>
        </div>
      </section>

      {/* What We Define Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-12">
              O Que Nos Define
            </h2>
            
            <p className="text-xl text-gray-600 mb-12">
              Nossa equipe é o coração da "Anfitrião Mor". Somos um time multidisciplinar focado em:
            </p>

            <div className="grid md:grid-cols-3 gap-8">
              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-navy-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <TrendingUp className="w-6 h-6 text-navy-600" />
                  </div>
                  <CardTitle className="text-center text-navy-900">Maximizar Rentabilidade</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Estratégias de precificação inteligentes para seu imóvel
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-gold-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Shield className="w-6 h-6 text-gold-600" />
                  </div>
                  <CardTitle className="text-center text-navy-900">Garantir Segurança</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Proteção completa dos seus bens e propriedade
                  </p>
                </CardContent>
              </Card>

              <Card className="border-0 shadow-lg hover:shadow-xl transition-all duration-300">
                <CardHeader>
                  <div className="w-12 h-12 bg-navy-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                    <Star className="w-6 h-6 text-navy-600" />
                  </div>
                  <CardTitle className="text-center text-navy-900">Serviço Impecável</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-gray-600 text-center">
                    Automação e qualidade em cada interação
                  </p>
                </CardContent>
              </Card>
            </div>

            <div className="mt-12 p-8 bg-gradient-to-r from-navy-800 to-navy-900 rounded-2xl text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gold-400 opacity-10 rounded-full -translate-y-16 translate-x-16"></div>
              <h3 className="text-2xl font-bold mb-4">
                Convidamos você a deixar seu imóvel trabalhar por você
              </h3>
              <p className="text-xl mb-6">Nós cuidamos de tudo.</p>
              <Button onClick={scrollToContact} className="bg-gold-500 hover:bg-gold-600 text-black font-semibold" size="lg">
                Começar Agora
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
              O Que Nossos Clientes Dizem
            </h2>
            <p className="text-xl text-gray-600">
              Proprietários satisfeitos em Amsterdam e Curitiba
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <TestimonialCard key={index} {...testimonial} />
            ))}
          </div>
        </div>
      </section>

      {/* Contact Form Section */}
      <section id="contact" className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-3xl md:text-4xl font-bold text-navy-900 mb-4">
                Pronto para Maximizar sua Renda?
              </h2>
              <p className="text-xl text-gray-600">
                Entre em contato conosco para uma consultoria gratuita
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-2xl font-semibold text-navy-900 mb-6">
                  Entre em Contato
                </h3>
                
                <div className="space-y-6">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-navy-100 rounded-lg flex items-center justify-center mr-4">
                      <Phone className="w-6 h-6 text-navy-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-navy-900">Telefone</h4>
                      <p className="text-gray-600">(41) 98747-6580</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gold-100 rounded-lg flex items-center justify-center mr-4">
                      <Mail className="w-6 h-6 text-gold-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-navy-900">Email</h4>
                      <p className="text-gray-600">info@anfitriao-mor.com.br</p>
                    </div>
                  </div>

                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-navy-100 rounded-lg flex items-center justify-center mr-4">
                      <MapPin className="w-6 h-6 text-navy-600" />
                    </div>
                    <div>
                      <h4 className="font-semibold text-navy-900">Localização</h4>
                      <p className="text-gray-600">Curitiba, Paraná</p>
                    </div>
                  </div>
                </div>

                <div className="mt-8 p-6 bg-gradient-to-br from-navy-50 to-gold-50 rounded-lg border border-navy-100">
                  <h4 className="font-semibold text-navy-900 mb-2">
                    Consultoria Gratuita
                  </h4>
                  <p className="text-gray-600">
                    Agende uma conversa para descobrir o potencial de renda do seu imóvel
                  </p>
                </div>
              </div>

              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-navy-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="/assets/logo.png" 
                  alt="Anfitrião-mor Logo" 
                  className="w-8 h-8 object-contain"
                />
                <span className="text-xl font-bold">Anfitrião-mor</span>
              </div>
              <p className="text-gray-300">
                Transformando propriedades em fontes de renda com expertise internacional.
              </p>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-gold-400">Serviços</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Gestão Airbnb</li>
                <li>Precificação Dinâmica</li>
                <li>Automação de Processos</li>
                <li>Suporte 24/7</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-gold-400">Empresa</h4>
              <ul className="space-y-2 text-gray-300">
                <li>Sobre Nós</li>
                <li>Nossa História</li>
                <li>Depoimentos</li>
                <li>Contato</li>
              </ul>
            </div>

            <div>
              <h4 className="font-semibold mb-4 text-gold-400">Contato</h4>
              <ul className="space-y-2 text-gray-300">
                <li>(41) 98747-6580</li>
                <li>info@anfitriao-mor.com.br</li>
                <li>Curitiba, PR</li>
              </ul>
            </div>
          </div>

          <div className="border-t border-navy-700 mt-8 pt-8 text-center text-gray-300">
            <p>&copy; 2024 Anfitrião-mor. Todos os direitos reservados.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}