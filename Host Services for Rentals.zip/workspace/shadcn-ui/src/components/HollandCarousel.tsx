import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight, ExternalLink } from 'lucide-react';

export default function HollandCarousel() {
  const [currentSlide, setCurrentSlide] = useState(0);

  const properties = [
    {
      image: '/assets/holland-property-1.webp',
      alt: 'Casa na Holanda - Vista da água'
    },
    {
      image: '/assets/holland-property-2.webp',
      alt: 'Casa na Holanda - Propriedade com jardim'
    },
    {
      image: '/assets/holland-property-3.jpg',
      alt: 'Casa na Holanda - Vista do rio'
    }
  ];

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % properties.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + properties.length) % properties.length);
  };

  // Auto-play carousel
  useEffect(() => {
    const interval = setInterval(nextSlide, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <section className="py-16 bg-gradient-to-br from-slate-50 to-yellow-50">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">
            Nossas Propriedades na Holanda
          </h2>
          <p className="text-xl text-slate-600 mb-8">
            Venha conhecer a Holanda
          </p>
          <p className="text-gray-600 max-w-2xl mx-auto mb-8">
            Estas são algumas das propriedades que gerenciamos em Amsterdam e região. 
            A mesma expertise e cuidado que aplicamos lá, trazemos para o Brasil.
          </p>
        </div>

        <div className="max-w-4xl mx-auto">
          <Card className="border-0 shadow-2xl overflow-hidden bg-white">
            <CardContent className="p-0 relative">
              <div className="relative h-96 md:h-[500px] overflow-hidden">
                {properties.map((property, index) => (
                  <div
                    key={index}
                    className={`absolute inset-0 transition-transform duration-500 ease-in-out ${
                      index === currentSlide ? 'translate-x-0' : 
                      index < currentSlide ? '-translate-x-full' : 'translate-x-full'
                    }`}
                  >
                    <img
                      src={property.image}
                      alt={property.alt}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                  </div>
                ))}

                {/* Navigation Buttons */}
                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm"
                  onClick={prevSlide}
                >
                  <ChevronLeft className="h-6 w-6" />
                </Button>

                <Button
                  variant="ghost"
                  size="icon"
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 bg-white/20 hover:bg-white/30 text-white backdrop-blur-sm"
                  onClick={nextSlide}
                >
                  <ChevronRight className="h-6 w-6" />
                </Button>

                {/* Slide Indicators */}
                <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                  {properties.map((_, index) => (
                    <button
                      key={index}
                      className={`w-3 h-3 rounded-full transition-all duration-300 ${
                        index === currentSlide 
                          ? 'bg-yellow-400 w-8' 
                          : 'bg-white/50 hover:bg-white/75'
                      }`}
                      onClick={() => setCurrentSlide(index)}
                    />
                  ))}
                </div>

                {/* Caption */}
                <div className="absolute bottom-12 left-6 right-6 text-center">
                  <h3 className="text-2xl font-bold text-white mb-2">
                    Venha conhecer a Holanda
                  </h3>
                  <p className="text-white/90 text-lg">
                    Experiência internacional em gestão hoteleira
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="text-center mt-8">
            <a
              href="https://www.boonvakantie.nl/fr/listings/260017"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-slate-900 hover:bg-slate-800 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              <ExternalLink className="w-5 h-5" />
              Ver Propriedade no Boon Vakantie
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}